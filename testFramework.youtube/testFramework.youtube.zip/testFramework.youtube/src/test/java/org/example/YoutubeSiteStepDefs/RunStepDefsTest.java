package org.example.YoutubeSiteStepDefs;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(features = {"C:\\Users\\sabri\\IdeaProjects\\testFramework.youtube\\src\\test\\resources\\YoutubeSite.feature"}
)
public class RunStepDefsTest {
}
